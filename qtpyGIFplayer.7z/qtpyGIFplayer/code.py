import board
import displayio
import adafruit_displayio_ssd1306
import gifio
import time
import gc

# Release any existing displays
displayio.release_displays()

# Configure SPI
spi = board.SPI()
tft_cs = board.D16  # Chip select
tft_dc = board.D5  # Data/command
tft_reset = board.D6  # Reset

# Initialize SPI bus
display_bus = displayio.FourWire(
    spi,
    command=tft_dc,
    chip_select=tft_cs,
    reset=tft_reset,
    baudrate=1000000  # 1 MHz; can be increased for faster refresh
)

# Initialize SSD1306 display
display = adafruit_displayio_ssd1306.SSD1306(
    display_bus,
    width=128,
    height=64
)

# Main loop to play GIF
while True:
    # Open GIF file from CIRCUITPY drive
    odg = gifio.OnDiskGif('/gifs/sample.gif')  # Store GIFs in /gifs folder

    # Create a TileGrid to display the GIF
    face = displayio.TileGrid(
        odg.bitmap,
        pixel_shader=displayio.ColorConverter(
            input_colorspace=displayio.Colorspace.L8  # Use L8 for monochrome conversion
        )
    )

    # Create a Group and show the GIF
    group = displayio.Group()
    group.append(face)
    display.root_group = group

    # Play the GIF in a loop
    next_delay = odg.next_frame()  # Load first frame
    start_time = time.monotonic()

    while True:
        # Wait for the next frame delay
        time.sleep(max(0, next_delay - (time.monotonic() - start_time)))
        start_time = time.monotonic()
        next_delay = odg.next_frame()  # Load next frame

        # Exit inner loop if GIF ends (for non-looping GIFs)
        if odg.frame_count == odg.frame_count - 1:
            break

    # Cleanup memory
    odg.deinit()
    gc.collect()